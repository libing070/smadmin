/*头条数据访问明细					
发帖人	发帖日期	主题	点击量	评论数	点赞数
	*/

SELECT 	u.nickname 发帖人昵称,h.mobile	发帖人手机号码,	h.create_date 发帖日期,	h.title 主题,h.click_num	点击量,	h.reply_num 评论数,h.praise_num	点赞数		
from headline_content h,user_info u   where h.mobile=u.mobile and date_format(h.create_date, '%Y-%m-%d %H:%i:%s') >=
                       date_format('2014-10-20', '%Y-%m-%d %H:%i:%s') and date_format(h.create_date, '%Y-%m-%d %H:%i:%s') <
                       date_format('2014-10-29', '%Y-%m-%d %H:%i:%s') order by h.create_date
 

					
					
