

/**活动明细
** 活动角色，1是抢桌，0是拼桌
**/
select pc.act_desc '活动名称',p.join_date '日期', u.nickname '用户名',u.mobile '手机号',p.is_owner_mobile '活动角色' 
from pin_createtable_detail p,user_info u,pin_createtable pc  
where p.mobile = u.mobile  and p.flash_sale_id=pc.flash_sale_id 
and date_format(p.join_date, '%Y-%m-%d %H:%i:%s') >=
                       date_format('2014-10-20', '%Y-%m-%d %H:%i:%s') and date_format(p.join_date, '%Y-%m-%d %H:%i:%s') <
                       date_format('2014-10-28', '%Y-%m-%d %H:%i:%s') order by   p.join_date desc